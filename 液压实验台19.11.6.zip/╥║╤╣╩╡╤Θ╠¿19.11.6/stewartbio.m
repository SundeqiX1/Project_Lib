

function bio=stewartbio(flag)
bio = [];
if nargin==0
  bio = [];

                    bio(1).blkName='Signal Generator';
bio(1).sigName='NULL';
bio(1).portIdx=0;
bio(1).dim=[1,1];
bio(1).sigWidth=1;
bio(1).sigAddress='&stewart_B.SignalGenerator';

bio(2).blkName='Signal Generator1';
bio(2).sigName='NULL';
bio(2).portIdx=0;
bio(2).dim=[1,1];
bio(2).sigWidth=1;
bio(2).sigAddress='&stewart_B.SignalGenerator1';

bio(3).blkName='Signal Generator10';
bio(3).sigName='NULL';
bio(3).portIdx=0;
bio(3).dim=[1,1];
bio(3).sigWidth=1;
bio(3).sigAddress='&stewart_B.SignalGenerator10';

bio(4).blkName='Signal Generator11';
bio(4).sigName='NULL';
bio(4).portIdx=0;
bio(4).dim=[1,1];
bio(4).sigWidth=1;
bio(4).sigAddress='&stewart_B.SignalGenerator11';

bio(5).blkName='Signal Generator12';
bio(5).sigName='NULL';
bio(5).portIdx=0;
bio(5).dim=[1,1];
bio(5).sigWidth=1;
bio(5).sigAddress='&stewart_B.SignalGenerator12';

bio(6).blkName='Signal Generator13';
bio(6).sigName='NULL';
bio(6).portIdx=0;
bio(6).dim=[1,1];
bio(6).sigWidth=1;
bio(6).sigAddress='&stewart_B.SignalGenerator13';

bio(7).blkName='Signal Generator14';
bio(7).sigName='NULL';
bio(7).portIdx=0;
bio(7).dim=[1,1];
bio(7).sigWidth=1;
bio(7).sigAddress='&stewart_B.SignalGenerator14';

bio(8).blkName='Signal Generator15';
bio(8).sigName='NULL';
bio(8).portIdx=0;
bio(8).dim=[1,1];
bio(8).sigWidth=1;
bio(8).sigAddress='&stewart_B.SignalGenerator15';

bio(9).blkName='Signal Generator16';
bio(9).sigName='NULL';
bio(9).portIdx=0;
bio(9).dim=[1,1];
bio(9).sigWidth=1;
bio(9).sigAddress='&stewart_B.SignalGenerator16';

bio(10).blkName='Signal Generator17';
bio(10).sigName='NULL';
bio(10).portIdx=0;
bio(10).dim=[1,1];
bio(10).sigWidth=1;
bio(10).sigAddress='&stewart_B.SignalGenerator17';

bio(11).blkName='Signal Generator2';
bio(11).sigName='NULL';
bio(11).portIdx=0;
bio(11).dim=[1,1];
bio(11).sigWidth=1;
bio(11).sigAddress='&stewart_B.SignalGenerator2';

bio(12).blkName='Signal Generator3';
bio(12).sigName='NULL';
bio(12).portIdx=0;
bio(12).dim=[1,1];
bio(12).sigWidth=1;
bio(12).sigAddress='&stewart_B.SignalGenerator3';

bio(13).blkName='Signal Generator4';
bio(13).sigName='NULL';
bio(13).portIdx=0;
bio(13).dim=[1,1];
bio(13).sigWidth=1;
bio(13).sigAddress='&stewart_B.SignalGenerator4';

bio(14).blkName='Signal Generator5';
bio(14).sigName='NULL';
bio(14).portIdx=0;
bio(14).dim=[1,1];
bio(14).sigWidth=1;
bio(14).sigAddress='&stewart_B.SignalGenerator5';

bio(15).blkName='Signal Generator6';
bio(15).sigName='NULL';
bio(15).portIdx=0;
bio(15).dim=[1,1];
bio(15).sigWidth=1;
bio(15).sigAddress='&stewart_B.SignalGenerator6';

bio(16).blkName='Signal Generator7';
bio(16).sigName='NULL';
bio(16).portIdx=0;
bio(16).dim=[1,1];
bio(16).sigWidth=1;
bio(16).sigAddress='&stewart_B.SignalGenerator7';

bio(17).blkName='Signal Generator8';
bio(17).sigName='NULL';
bio(17).portIdx=0;
bio(17).dim=[1,1];
bio(17).sigWidth=1;
bio(17).sigAddress='&stewart_B.SignalGenerator8';

bio(18).blkName='Signal Generator9';
bio(18).sigName='NULL';
bio(18).portIdx=0;
bio(18).dim=[1,1];
bio(18).sigWidth=1;
bio(18).sigAddress='&stewart_B.SignalGenerator9';

bio(19).blkName='DataSentHost/Clock';
bio(19).sigName='NULL';
bio(19).portIdx=0;
bio(19).dim=[1,1];
bio(19).sigWidth=1;
bio(19).sigAddress='&stewart_B.Clock';

bio(20).blkName='DataSentHost/Data Type Conversion15';
bio(20).sigName='NULL';
bio(20).portIdx=0;
bio(20).dim=[36,1];
bio(20).sigWidth=36;
bio(20).sigAddress='&stewart_B.DataTypeConversion15[0]';

bio(21).blkName='DataSentHost/Data Type Conversion8';
bio(21).sigName='NULL';
bio(21).portIdx=0;
bio(21).dim=[36,1];
bio(21).sigWidth=36;
bio(21).sigAddress='&stewart_B.DataTypeConversion8[0]';

bio(22).blkName='DataSentHost/Encoded_data';
bio(22).sigName='NULL';
bio(22).portIdx=0;
bio(22).dim=[10,1];
bio(22).sigWidth=10;
bio(22).sigAddress='&stewart_B.Encoded_data[0]';

bio(23).blkName='DataSentHost/Gain';
bio(23).sigName='NULL';
bio(23).portIdx=0;
bio(23).dim=[36,1];
bio(23).sigWidth=36;
bio(23).sigAddress='&stewart_B.Gain[0]';

bio(24).blkName='DataSentHost/Product';
bio(24).sigName='NULL';
bio(24).portIdx=0;
bio(24).dim=[6,1];
bio(24).sigWidth=6;
bio(24).sigAddress='&stewart_B.Product[0]';

bio(25).blkName='DataSentHost/Product1';
bio(25).sigName='NULL';
bio(25).portIdx=0;
bio(25).dim=[6,1];
bio(25).sigWidth=6;
bio(25).sigAddress='&stewart_B.Product1[0]';

bio(26).blkName='DataSentHost/Pack1';
bio(26).sigName='NULL';
bio(26).portIdx=0;
bio(26).dim=[72,1];
bio(26).sigWidth=72;
bio(26).sigAddress='&stewart_B.Pack1[0]';

bio(27).blkName='DataSentHost/encoded data';
bio(27).sigName='NULL';
bio(27).portIdx=0;
bio(27).dim=[9,1];
bio(27).sigWidth=9;
bio(27).sigAddress='&stewart_B.encodeddata[0]';

bio(28).blkName='DataSentHost/Sum2';
bio(28).sigName='NULL';
bio(28).portIdx=0;
bio(28).dim=[36,1];
bio(28).sigWidth=36;
bio(28).sigAddress='&stewart_B.Sum2[0]';

else
   bio= 266;
end
