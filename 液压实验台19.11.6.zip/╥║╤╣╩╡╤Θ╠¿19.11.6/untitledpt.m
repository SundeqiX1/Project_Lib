function pt=untitledpt
pt = [];

  
pt(1).blockname = 'Constant';
pt(1).paramname = 'Value';
pt(1).class     = 'scalar';
pt(1).nrows     = 1;
pt(1).ncols     = 1;
pt(1).subsource = 'SS_DOUBLE';
pt(1).ndims     = '2';
pt(1).size      = '[]';
pt(1).isStruct  = false;
pt(1).symbol     = 'untitled_P.Constant_Value';
pt(1).baseaddr   = '&untitled_P.Constant_Value';
pt(1).dtname     = 'real_T';

pt(getlenPT) = pt(1);


  
pt(2).blockname = 'PCI-2';
pt(2).paramname = 'P1';
pt(2).class     = 'vector';
pt(2).nrows     = 1;
pt(2).ncols     = 2;
pt(2).subsource = 'SS_DOUBLE';
pt(2).ndims     = '2';
pt(2).size      = '[]';
pt(2).isStruct  = false;
pt(2).symbol     = 'untitled_P.PCI2_P1';
pt(2).baseaddr   = '&untitled_P.PCI2_P1[0]';
pt(2).dtname     = 'real_T';



  
pt(3).blockname = 'PCI-2';
pt(3).paramname = 'P2';
pt(3).class     = 'vector';
pt(3).nrows     = 1;
pt(3).ncols     = 2;
pt(3).subsource = 'SS_DOUBLE';
pt(3).ndims     = '2';
pt(3).size      = '[]';
pt(3).isStruct  = false;
pt(3).symbol     = 'untitled_P.PCI2_P2';
pt(3).baseaddr   = '&untitled_P.PCI2_P2[0]';
pt(3).dtname     = 'real_T';



  
pt(4).blockname = 'PCI-6208A DA ';
pt(4).paramname = 'P1';
pt(4).class     = 'vector';
pt(4).nrows     = 1;
pt(4).ncols     = 8;
pt(4).subsource = 'SS_DOUBLE';
pt(4).ndims     = '2';
pt(4).size      = '[]';
pt(4).isStruct  = false;
pt(4).symbol     = 'untitled_P.PCI6208ADA_P1';
pt(4).baseaddr   = '&untitled_P.PCI6208ADA_P1[0]';
pt(4).dtname     = 'real_T';



  
pt(5).blockname = 'PCI-6208A DA ';
pt(5).paramname = 'P2';
pt(5).class     = 'scalar';
pt(5).nrows     = 1;
pt(5).ncols     = 1;
pt(5).subsource = 'SS_DOUBLE';
pt(5).ndims     = '2';
pt(5).size      = '[]';
pt(5).isStruct  = false;
pt(5).symbol     = 'untitled_P.PCI6208ADA_P2';
pt(5).baseaddr   = '&untitled_P.PCI6208ADA_P2';
pt(5).dtname     = 'real_T';



  
pt(6).blockname = 'PCI-6208A DA ';
pt(6).paramname = 'P3';
pt(6).class     = 'scalar';
pt(6).nrows     = 1;
pt(6).ncols     = 1;
pt(6).subsource = 'SS_DOUBLE';
pt(6).ndims     = '2';
pt(6).size      = '[]';
pt(6).isStruct  = false;
pt(6).symbol     = 'untitled_P.PCI6208ADA_P3';
pt(6).baseaddr   = '&untitled_P.PCI6208ADA_P3';
pt(6).dtname     = 'real_T';



  
pt(7).blockname = 'PCI-6208A DA ';
pt(7).paramname = 'P4';
pt(7).class     = 'vector';
pt(7).nrows     = 1;
pt(7).ncols     = 2;
pt(7).subsource = 'SS_DOUBLE';
pt(7).ndims     = '2';
pt(7).size      = '[]';
pt(7).isStruct  = false;
pt(7).symbol     = 'untitled_P.PCI6208ADA_P4';
pt(7).baseaddr   = '&untitled_P.PCI6208ADA_P4[0]';
pt(7).dtname     = 'real_T';



  
pt(8).blockname = 'PCI-6208A DA ';
pt(8).paramname = 'P5';
pt(8).class     = 'vector';
pt(8).nrows     = 1;
pt(8).ncols     = 8;
pt(8).subsource = 'SS_DOUBLE';
pt(8).ndims     = '2';
pt(8).size      = '[]';
pt(8).isStruct  = false;
pt(8).symbol     = 'untitled_P.PCI6208ADA_P5';
pt(8).baseaddr   = '&untitled_P.PCI6208ADA_P5[0]';
pt(8).dtname     = 'real_T';



  
pt(9).blockname = 'PCI-6208A DA ';
pt(9).paramname = 'P6';
pt(9).class     = 'vector';
pt(9).nrows     = 1;
pt(9).ncols     = 8;
pt(9).subsource = 'SS_DOUBLE';
pt(9).ndims     = '2';
pt(9).size      = '[]';
pt(9).isStruct  = false;
pt(9).symbol     = 'untitled_P.PCI6208ADA_P6';
pt(9).baseaddr   = '&untitled_P.PCI6208ADA_P6[0]';
pt(9).dtname     = 'real_T';


function len = getlenPT
len = 9;

