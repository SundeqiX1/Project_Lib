/*
 * simpleCylinder1_capi.h
 *
 * Real-Time Workshop code generation for Simulink model "simpleCylinder1.mdl".
 *
 * Model Version              : 1.34
 * Real-Time Workshop version : 6.5  (R2006b)  03-Aug-2006
 * C source code generated on : Thu Nov 26 15:47:16 2020
 */
#ifndef _RTW_HEADER_simpleCylinder1_capi_h_
#define _RTW_HEADER_simpleCylinder1_capi_h_
#include "simpleCylinder1.h"

extern void simpleCylinder1_InitializeDataMapInfo(rtModel_simpleCylinder1
  *simpleCylinder1_rtM
  );

#endif                                 /* _RTW_HEADER_simpleCylinder1_capi_h_ */

/* EOF: simpleCylinder1_capi.h */
