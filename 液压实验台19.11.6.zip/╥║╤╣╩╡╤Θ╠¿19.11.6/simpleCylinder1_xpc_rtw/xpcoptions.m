
function info=xpcoptions
info.objname='tg';
info.xpcObjCom=0;
