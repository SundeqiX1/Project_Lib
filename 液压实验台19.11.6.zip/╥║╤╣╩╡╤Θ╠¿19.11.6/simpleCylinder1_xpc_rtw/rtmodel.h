/*
 *  rtmodel.h:
 *
 * Real-Time Workshop code generation for Simulink model "simpleCylinder1.mdl".
 *
 * Model Version              : 1.34
 * Real-Time Workshop version : 6.5  (R2006b)  03-Aug-2006
 * C source code generated on : Thu Nov 26 15:47:16 2020
 */
#ifndef _RTW_HEADER_rtmodel_h_
#define _RTW_HEADER_rtmodel_h_

/*
 *  Includes the appropriate headers when we are using rtModel
 */
#include "simpleCylinder1.h"
#endif                                 /* _RTW_HEADER_rtmodel_h_ */
