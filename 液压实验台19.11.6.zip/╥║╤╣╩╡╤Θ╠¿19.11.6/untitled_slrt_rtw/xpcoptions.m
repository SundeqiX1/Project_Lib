
function info=xpcoptions
info.objname='tg';
info.xpcObjCom=0;
  info.SampleTimes(1).PeriodAndOffset = [0.001 0.0];
  info.SampleTimes(1).PriorityAssigned = 'yes';
    info.SampleTimes(1).Priority = 40;
  info.SampleTimes(1).TID = 0;

