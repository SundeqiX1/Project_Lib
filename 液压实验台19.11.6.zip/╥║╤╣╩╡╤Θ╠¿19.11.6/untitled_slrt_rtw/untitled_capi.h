/*
 * untitled_capi.h
 *
 * Code generation for model "untitled".
 *
 * Model version              : 1.0
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Tue Mar 02 16:42:12 2021
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_untitled_capi_h
#define RTW_HEADER_untitled_capi_h
#include "untitled.h"

extern void untitled_InitializeDataMapInfo(RT_MODEL_untitled_T *const untitled_M
  );

#endif                                 /* RTW_HEADER_untitled_capi_h */

/* EOF: untitled_capi.h */
