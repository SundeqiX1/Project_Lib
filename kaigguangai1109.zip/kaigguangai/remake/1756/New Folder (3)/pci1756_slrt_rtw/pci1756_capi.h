/*
 * pci1756_capi.h
 *
 * Code generation for model "pci1756".
 *
 * Model version              : 1.9
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon Jul 12 11:27:47 2021
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pci1756_capi_h
#define RTW_HEADER_pci1756_capi_h
#include "pci1756.h"

extern void pci1756_InitializeDataMapInfo(RT_MODEL_pci1756_T *const pci1756_M
  );

#endif                                 /* RTW_HEADER_pci1756_capi_h */

/* EOF: pci1756_capi.h */
