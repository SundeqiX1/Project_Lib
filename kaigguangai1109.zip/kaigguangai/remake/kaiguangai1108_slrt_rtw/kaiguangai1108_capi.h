/*
 * kaiguangai1108_capi.h
 *
 * Code generation for model "kaiguangai1108".
 *
 * Model version              : 1.85
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Tue Nov 09 15:31:44 2021
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_kaiguangai1108_capi_h
#define RTW_HEADER_kaiguangai1108_capi_h
#include "kaiguangai1108.h"

extern void kaiguangai1108_InitializeDataMapInfo(RT_MODEL_kaiguangai1108_T *
  const kaiguangai1108_M
  );

#endif                                 /* RTW_HEADER_kaiguangai1108_capi_h */

/* EOF: kaiguangai1108_capi.h */
