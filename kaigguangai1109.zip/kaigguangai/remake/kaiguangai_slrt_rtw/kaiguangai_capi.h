/*
 * kaiguangai_capi.h
 *
 * Code generation for model "kaiguangai".
 *
 * Model version              : 1.82
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon Nov 08 15:15:50 2021
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_kaiguangai_capi_h
#define RTW_HEADER_kaiguangai_capi_h
#include "kaiguangai.h"

extern void kaiguangai_InitializeDataMapInfo(RT_MODEL_kaiguangai_T *const
  kaiguangai_M
  );

#endif                                 /* RTW_HEADER_kaiguangai_capi_h */

/* EOF: kaiguangai_capi.h */
