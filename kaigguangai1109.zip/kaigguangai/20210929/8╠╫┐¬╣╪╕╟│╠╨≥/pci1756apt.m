function pt=pci1756apt
pt = [];

  
pt(1).blockname = 'Constant';
pt(1).paramname = 'Value';
pt(1).class     = 'scalar';
pt(1).nrows     = 1;
pt(1).ncols     = 1;
pt(1).subsource = 'SS_DOUBLE';
pt(1).ndims     = '2';
pt(1).size      = '[]';
pt(1).isStruct  = false;
pt(1).symbol     = 'pci1756a_P.Constant_Value';
pt(1).baseaddr   = '&pci1756a_P.Constant_Value';
pt(1).dtname     = 'real_T';

pt(getlenPT) = pt(1);


  
pt(2).blockname = 'Constant1';
pt(2).paramname = 'Value';
pt(2).class     = 'scalar';
pt(2).nrows     = 1;
pt(2).ncols     = 1;
pt(2).subsource = 'SS_DOUBLE';
pt(2).ndims     = '2';
pt(2).size      = '[]';
pt(2).isStruct  = false;
pt(2).symbol     = 'pci1756a_P.Constant1_Value';
pt(2).baseaddr   = '&pci1756a_P.Constant1_Value';
pt(2).dtname     = 'real_T';



  
pt(3).blockname = 'Constant10';
pt(3).paramname = 'Value';
pt(3).class     = 'scalar';
pt(3).nrows     = 1;
pt(3).ncols     = 1;
pt(3).subsource = 'SS_DOUBLE';
pt(3).ndims     = '2';
pt(3).size      = '[]';
pt(3).isStruct  = false;
pt(3).symbol     = 'pci1756a_P.Constant10_Value';
pt(3).baseaddr   = '&pci1756a_P.Constant10_Value';
pt(3).dtname     = 'real_T';



  
pt(4).blockname = 'Constant11';
pt(4).paramname = 'Value';
pt(4).class     = 'scalar';
pt(4).nrows     = 1;
pt(4).ncols     = 1;
pt(4).subsource = 'SS_DOUBLE';
pt(4).ndims     = '2';
pt(4).size      = '[]';
pt(4).isStruct  = false;
pt(4).symbol     = 'pci1756a_P.Constant11_Value';
pt(4).baseaddr   = '&pci1756a_P.Constant11_Value';
pt(4).dtname     = 'real_T';



  
pt(5).blockname = 'Constant12';
pt(5).paramname = 'Value';
pt(5).class     = 'scalar';
pt(5).nrows     = 1;
pt(5).ncols     = 1;
pt(5).subsource = 'SS_DOUBLE';
pt(5).ndims     = '2';
pt(5).size      = '[]';
pt(5).isStruct  = false;
pt(5).symbol     = 'pci1756a_P.Constant12_Value';
pt(5).baseaddr   = '&pci1756a_P.Constant12_Value';
pt(5).dtname     = 'real_T';



  
pt(6).blockname = 'Constant13';
pt(6).paramname = 'Value';
pt(6).class     = 'scalar';
pt(6).nrows     = 1;
pt(6).ncols     = 1;
pt(6).subsource = 'SS_DOUBLE';
pt(6).ndims     = '2';
pt(6).size      = '[]';
pt(6).isStruct  = false;
pt(6).symbol     = 'pci1756a_P.Constant13_Value';
pt(6).baseaddr   = '&pci1756a_P.Constant13_Value';
pt(6).dtname     = 'real_T';



  
pt(7).blockname = 'Constant14';
pt(7).paramname = 'Value';
pt(7).class     = 'scalar';
pt(7).nrows     = 1;
pt(7).ncols     = 1;
pt(7).subsource = 'SS_DOUBLE';
pt(7).ndims     = '2';
pt(7).size      = '[]';
pt(7).isStruct  = false;
pt(7).symbol     = 'pci1756a_P.Constant14_Value';
pt(7).baseaddr   = '&pci1756a_P.Constant14_Value';
pt(7).dtname     = 'real_T';



  
pt(8).blockname = 'Constant15';
pt(8).paramname = 'Value';
pt(8).class     = 'scalar';
pt(8).nrows     = 1;
pt(8).ncols     = 1;
pt(8).subsource = 'SS_DOUBLE';
pt(8).ndims     = '2';
pt(8).size      = '[]';
pt(8).isStruct  = false;
pt(8).symbol     = 'pci1756a_P.Constant15_Value';
pt(8).baseaddr   = '&pci1756a_P.Constant15_Value';
pt(8).dtname     = 'real_T';



  
pt(9).blockname = 'Constant16';
pt(9).paramname = 'Value';
pt(9).class     = 'scalar';
pt(9).nrows     = 1;
pt(9).ncols     = 1;
pt(9).subsource = 'SS_DOUBLE';
pt(9).ndims     = '2';
pt(9).size      = '[]';
pt(9).isStruct  = false;
pt(9).symbol     = 'pci1756a_P.Constant16_Value';
pt(9).baseaddr   = '&pci1756a_P.Constant16_Value';
pt(9).dtname     = 'real_T';



  
pt(10).blockname = 'Constant17';
pt(10).paramname = 'Value';
pt(10).class     = 'scalar';
pt(10).nrows     = 1;
pt(10).ncols     = 1;
pt(10).subsource = 'SS_DOUBLE';
pt(10).ndims     = '2';
pt(10).size      = '[]';
pt(10).isStruct  = false;
pt(10).symbol     = 'pci1756a_P.Constant17_Value';
pt(10).baseaddr   = '&pci1756a_P.Constant17_Value';
pt(10).dtname     = 'real_T';



  
pt(11).blockname = 'Constant18';
pt(11).paramname = 'Value';
pt(11).class     = 'scalar';
pt(11).nrows     = 1;
pt(11).ncols     = 1;
pt(11).subsource = 'SS_DOUBLE';
pt(11).ndims     = '2';
pt(11).size      = '[]';
pt(11).isStruct  = false;
pt(11).symbol     = 'pci1756a_P.Constant18_Value';
pt(11).baseaddr   = '&pci1756a_P.Constant18_Value';
pt(11).dtname     = 'real_T';



  
pt(12).blockname = 'Constant19';
pt(12).paramname = 'Value';
pt(12).class     = 'scalar';
pt(12).nrows     = 1;
pt(12).ncols     = 1;
pt(12).subsource = 'SS_DOUBLE';
pt(12).ndims     = '2';
pt(12).size      = '[]';
pt(12).isStruct  = false;
pt(12).symbol     = 'pci1756a_P.Constant19_Value';
pt(12).baseaddr   = '&pci1756a_P.Constant19_Value';
pt(12).dtname     = 'real_T';



  
pt(13).blockname = 'Constant2';
pt(13).paramname = 'Value';
pt(13).class     = 'scalar';
pt(13).nrows     = 1;
pt(13).ncols     = 1;
pt(13).subsource = 'SS_DOUBLE';
pt(13).ndims     = '2';
pt(13).size      = '[]';
pt(13).isStruct  = false;
pt(13).symbol     = 'pci1756a_P.Constant2_Value';
pt(13).baseaddr   = '&pci1756a_P.Constant2_Value';
pt(13).dtname     = 'real_T';



  
pt(14).blockname = 'Constant20';
pt(14).paramname = 'Value';
pt(14).class     = 'scalar';
pt(14).nrows     = 1;
pt(14).ncols     = 1;
pt(14).subsource = 'SS_DOUBLE';
pt(14).ndims     = '2';
pt(14).size      = '[]';
pt(14).isStruct  = false;
pt(14).symbol     = 'pci1756a_P.Constant20_Value';
pt(14).baseaddr   = '&pci1756a_P.Constant20_Value';
pt(14).dtname     = 'real_T';



  
pt(15).blockname = 'Constant21';
pt(15).paramname = 'Value';
pt(15).class     = 'scalar';
pt(15).nrows     = 1;
pt(15).ncols     = 1;
pt(15).subsource = 'SS_DOUBLE';
pt(15).ndims     = '2';
pt(15).size      = '[]';
pt(15).isStruct  = false;
pt(15).symbol     = 'pci1756a_P.Constant21_Value';
pt(15).baseaddr   = '&pci1756a_P.Constant21_Value';
pt(15).dtname     = 'real_T';



  
pt(16).blockname = 'Constant22';
pt(16).paramname = 'Value';
pt(16).class     = 'scalar';
pt(16).nrows     = 1;
pt(16).ncols     = 1;
pt(16).subsource = 'SS_DOUBLE';
pt(16).ndims     = '2';
pt(16).size      = '[]';
pt(16).isStruct  = false;
pt(16).symbol     = 'pci1756a_P.Constant22_Value';
pt(16).baseaddr   = '&pci1756a_P.Constant22_Value';
pt(16).dtname     = 'real_T';



  
pt(17).blockname = 'Constant23';
pt(17).paramname = 'Value';
pt(17).class     = 'scalar';
pt(17).nrows     = 1;
pt(17).ncols     = 1;
pt(17).subsource = 'SS_DOUBLE';
pt(17).ndims     = '2';
pt(17).size      = '[]';
pt(17).isStruct  = false;
pt(17).symbol     = 'pci1756a_P.Constant23_Value';
pt(17).baseaddr   = '&pci1756a_P.Constant23_Value';
pt(17).dtname     = 'real_T';



  
pt(18).blockname = 'Constant24';
pt(18).paramname = 'Value';
pt(18).class     = 'scalar';
pt(18).nrows     = 1;
pt(18).ncols     = 1;
pt(18).subsource = 'SS_DOUBLE';
pt(18).ndims     = '2';
pt(18).size      = '[]';
pt(18).isStruct  = false;
pt(18).symbol     = 'pci1756a_P.Constant24_Value';
pt(18).baseaddr   = '&pci1756a_P.Constant24_Value';
pt(18).dtname     = 'real_T';



  
pt(19).blockname = 'Constant25';
pt(19).paramname = 'Value';
pt(19).class     = 'scalar';
pt(19).nrows     = 1;
pt(19).ncols     = 1;
pt(19).subsource = 'SS_DOUBLE';
pt(19).ndims     = '2';
pt(19).size      = '[]';
pt(19).isStruct  = false;
pt(19).symbol     = 'pci1756a_P.Constant25_Value';
pt(19).baseaddr   = '&pci1756a_P.Constant25_Value';
pt(19).dtname     = 'real_T';



  
pt(20).blockname = 'Constant26';
pt(20).paramname = 'Value';
pt(20).class     = 'scalar';
pt(20).nrows     = 1;
pt(20).ncols     = 1;
pt(20).subsource = 'SS_DOUBLE';
pt(20).ndims     = '2';
pt(20).size      = '[]';
pt(20).isStruct  = false;
pt(20).symbol     = 'pci1756a_P.Constant26_Value';
pt(20).baseaddr   = '&pci1756a_P.Constant26_Value';
pt(20).dtname     = 'real_T';



  
pt(21).blockname = 'Constant27';
pt(21).paramname = 'Value';
pt(21).class     = 'scalar';
pt(21).nrows     = 1;
pt(21).ncols     = 1;
pt(21).subsource = 'SS_DOUBLE';
pt(21).ndims     = '2';
pt(21).size      = '[]';
pt(21).isStruct  = false;
pt(21).symbol     = 'pci1756a_P.Constant27_Value';
pt(21).baseaddr   = '&pci1756a_P.Constant27_Value';
pt(21).dtname     = 'real_T';



  
pt(22).blockname = 'Constant28';
pt(22).paramname = 'Value';
pt(22).class     = 'scalar';
pt(22).nrows     = 1;
pt(22).ncols     = 1;
pt(22).subsource = 'SS_DOUBLE';
pt(22).ndims     = '2';
pt(22).size      = '[]';
pt(22).isStruct  = false;
pt(22).symbol     = 'pci1756a_P.Constant28_Value';
pt(22).baseaddr   = '&pci1756a_P.Constant28_Value';
pt(22).dtname     = 'real_T';



  
pt(23).blockname = 'Constant29';
pt(23).paramname = 'Value';
pt(23).class     = 'scalar';
pt(23).nrows     = 1;
pt(23).ncols     = 1;
pt(23).subsource = 'SS_DOUBLE';
pt(23).ndims     = '2';
pt(23).size      = '[]';
pt(23).isStruct  = false;
pt(23).symbol     = 'pci1756a_P.Constant29_Value';
pt(23).baseaddr   = '&pci1756a_P.Constant29_Value';
pt(23).dtname     = 'real_T';



  
pt(24).blockname = 'Constant3';
pt(24).paramname = 'Value';
pt(24).class     = 'scalar';
pt(24).nrows     = 1;
pt(24).ncols     = 1;
pt(24).subsource = 'SS_DOUBLE';
pt(24).ndims     = '2';
pt(24).size      = '[]';
pt(24).isStruct  = false;
pt(24).symbol     = 'pci1756a_P.Constant3_Value';
pt(24).baseaddr   = '&pci1756a_P.Constant3_Value';
pt(24).dtname     = 'real_T';



  
pt(25).blockname = 'Constant30';
pt(25).paramname = 'Value';
pt(25).class     = 'scalar';
pt(25).nrows     = 1;
pt(25).ncols     = 1;
pt(25).subsource = 'SS_DOUBLE';
pt(25).ndims     = '2';
pt(25).size      = '[]';
pt(25).isStruct  = false;
pt(25).symbol     = 'pci1756a_P.Constant30_Value';
pt(25).baseaddr   = '&pci1756a_P.Constant30_Value';
pt(25).dtname     = 'real_T';



  
pt(26).blockname = 'Constant31';
pt(26).paramname = 'Value';
pt(26).class     = 'scalar';
pt(26).nrows     = 1;
pt(26).ncols     = 1;
pt(26).subsource = 'SS_DOUBLE';
pt(26).ndims     = '2';
pt(26).size      = '[]';
pt(26).isStruct  = false;
pt(26).symbol     = 'pci1756a_P.Constant31_Value';
pt(26).baseaddr   = '&pci1756a_P.Constant31_Value';
pt(26).dtname     = 'real_T';



  
pt(27).blockname = 'Constant4';
pt(27).paramname = 'Value';
pt(27).class     = 'scalar';
pt(27).nrows     = 1;
pt(27).ncols     = 1;
pt(27).subsource = 'SS_DOUBLE';
pt(27).ndims     = '2';
pt(27).size      = '[]';
pt(27).isStruct  = false;
pt(27).symbol     = 'pci1756a_P.Constant4_Value';
pt(27).baseaddr   = '&pci1756a_P.Constant4_Value';
pt(27).dtname     = 'real_T';



  
pt(28).blockname = 'Constant5';
pt(28).paramname = 'Value';
pt(28).class     = 'scalar';
pt(28).nrows     = 1;
pt(28).ncols     = 1;
pt(28).subsource = 'SS_DOUBLE';
pt(28).ndims     = '2';
pt(28).size      = '[]';
pt(28).isStruct  = false;
pt(28).symbol     = 'pci1756a_P.Constant5_Value';
pt(28).baseaddr   = '&pci1756a_P.Constant5_Value';
pt(28).dtname     = 'real_T';



  
pt(29).blockname = 'Constant6';
pt(29).paramname = 'Value';
pt(29).class     = 'scalar';
pt(29).nrows     = 1;
pt(29).ncols     = 1;
pt(29).subsource = 'SS_DOUBLE';
pt(29).ndims     = '2';
pt(29).size      = '[]';
pt(29).isStruct  = false;
pt(29).symbol     = 'pci1756a_P.Constant6_Value';
pt(29).baseaddr   = '&pci1756a_P.Constant6_Value';
pt(29).dtname     = 'real_T';



  
pt(30).blockname = 'Constant7';
pt(30).paramname = 'Value';
pt(30).class     = 'scalar';
pt(30).nrows     = 1;
pt(30).ncols     = 1;
pt(30).subsource = 'SS_DOUBLE';
pt(30).ndims     = '2';
pt(30).size      = '[]';
pt(30).isStruct  = false;
pt(30).symbol     = 'pci1756a_P.Constant7_Value';
pt(30).baseaddr   = '&pci1756a_P.Constant7_Value';
pt(30).dtname     = 'real_T';



  
pt(31).blockname = 'Constant8';
pt(31).paramname = 'Value';
pt(31).class     = 'scalar';
pt(31).nrows     = 1;
pt(31).ncols     = 1;
pt(31).subsource = 'SS_DOUBLE';
pt(31).ndims     = '2';
pt(31).size      = '[]';
pt(31).isStruct  = false;
pt(31).symbol     = 'pci1756a_P.Constant8_Value';
pt(31).baseaddr   = '&pci1756a_P.Constant8_Value';
pt(31).dtname     = 'real_T';



  
pt(32).blockname = 'Constant9';
pt(32).paramname = 'Value';
pt(32).class     = 'scalar';
pt(32).nrows     = 1;
pt(32).ncols     = 1;
pt(32).subsource = 'SS_DOUBLE';
pt(32).ndims     = '2';
pt(32).size      = '[]';
pt(32).isStruct  = false;
pt(32).symbol     = 'pci1756a_P.Constant9_Value';
pt(32).baseaddr   = '&pci1756a_P.Constant9_Value';
pt(32).dtname     = 'real_T';



  
pt(33).blockname = 'PCI1';
pt(33).paramname = 'P1';
pt(33).class     = 'scalar';
pt(33).nrows     = 1;
pt(33).ncols     = 1;
pt(33).subsource = 'SS_DOUBLE';
pt(33).ndims     = '2';
pt(33).size      = '[]';
pt(33).isStruct  = false;
pt(33).symbol     = 'pci1756a_P.PCI1_P1';
pt(33).baseaddr   = '&pci1756a_P.PCI1_P1';
pt(33).dtname     = 'real_T';



  
pt(34).blockname = 'PCI1';
pt(34).paramname = 'P2';
pt(34).class     = 'vector';
pt(34).nrows     = 1;
pt(34).ncols     = 2;
pt(34).subsource = 'SS_DOUBLE';
pt(34).ndims     = '2';
pt(34).size      = '[]';
pt(34).isStruct  = false;
pt(34).symbol     = 'pci1756a_P.PCI1_P2';
pt(34).baseaddr   = '&pci1756a_P.PCI1_P2[0]';
pt(34).dtname     = 'real_T';


function len = getlenPT
len = 34;

